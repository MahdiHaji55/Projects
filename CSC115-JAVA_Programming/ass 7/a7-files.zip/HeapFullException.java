public class HeapFullException extends RuntimeException {
}
